def setup_module():
    import pytest

    pytest.skip("portuguese_en.doctest imports nltk.examples.pt which doesn't exist!")
